
const app=document.getElementById('app'), drawer=document.getElementById('drawer');
document.getElementById('menuBtn').onclick=()=>drawer.classList.toggle('open');
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function toast(x){let t=document.getElementById('toast');t.textContent=x;t.style.display='block';setTimeout(()=>t.style.display='none',2500)}
function openPage(p){
 drawer.classList.remove('open');
 if(p==='login') return login();
 if(p==='register') return register();
 if(p==='deposit') return page('Instant UPI Deposit','Add money to your wallet. Connect your preferred payment gateway here before accepting real payments.','UPI deposit flow ready for gateway configuration.');
 if(p==='history') return page('Transaction History','Your deposits and wallet transactions will appear here.','No transactions yet.');
 if(p==='orders') return page('My Orders','Purchased items will appear here after a successful order.','No orders yet.');
 if(p==='reseller') return page('My Reseller','Reseller information and referral details will appear here.','Reseller tools are ready for backend connection.');
 if(p==='profile') return page('My Profile','Account details and wallet information.','Login to view your account.');
 if(p==='menu') return page('Account Menu','Use the sidebar to open Shop, Deposit, Orders, History and Reseller.');
 return shop();
}
function page(title,sub,body){app.innerHTML=`<section class="hero"><h1>${title}</h1><p>${sub}</p><div class="card">${body}</div></section>`}
function shop(){app.innerHTML=`<section class="hero"><h1>DEENU MODZ PANEL SHOP</h1><p>Select a category. Product listings are intentionally empty so you can add your own products later.</p></section>
<div class="grid">
<div class="card"><span class="cat">ROOT + NONROOT</span><div class="feature">⚡ Your product will appear here</div><div class="feature">⚡ Your product features</div><button class="btn" onclick="toast('Product area ready for your products')">VIEW PRODUCTS</button></div>
<div class="card"><span class="cat">FREEFIRE</span><div class="feature">⚡ Your product will appear here</div><div class="feature">⚡ Your product features</div><button class="btn" onclick="toast('Product area ready for your products')">VIEW PRODUCTS</button></div>
</div>
<div class="grid"><button class="btn" onclick="openPage('deposit')">⇩ CHECK UPDATE FILE</button><button class="btn red" onclick="toast('Feedback/video link can be configured here')">▶ CHECK VIDEO/FEEDBACK</button></div>`}
function login(){app.innerHTML=`<section class="form hero"><h1>Login</h1><input id="liUser" class="input" placeholder="Username or Email"><input id="liPass" class="input" type="password" placeholder="Password"><button class="btn" onclick="doLogin()">LOGIN</button><div class="switch" onclick="register()">Create Account</div></section>`}
function register(){app.innerHTML=`<section class="form hero"><h1>Create Account</h1><input id="rgUser" class="input" placeholder="Username"><input id="rgEmail" class="input" placeholder="Email"><input id="rgPass" class="input" type="password" placeholder="Password"><button class="btn" onclick="doRegister()">CREATE ACCOUNT</button><div class="switch" onclick="login()">Already have an account? Login</div></section>`}
async function post(url,data){let r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(data)});let j=await r.json().catch(()=>({error:'Server response error'}));if(!r.ok)throw Error(j.error||'Request failed');return j}
async function doRegister(){try{let j=await post('/api/auth/register',{username:rgUser.value,email:rgEmail.value,password:rgPass.value});toast('Account created');openPage('shop')}catch(e){toast(e.message)}}
async function doLogin(){try{let j=await post('/api/auth/login',{login:liUser.value,password:liPass.value});toast('Login successful');openPage('shop')}catch(e){toast(e.message)}}
async function logout(){try{await fetch('/api/auth/logout',{method:'POST'});toast('Logged out')}catch{}openPage('login')}
shop();

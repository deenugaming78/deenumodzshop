
import { sha256 } from "../_crypto.js";
function cookie(name,value,maxAge){return `${name}=${value}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Lax`}
export async function onRequestPost({request,env}) {
 const {login,password}=await request.json();
 if(!login||!password) return Response.json({error:"Enter login and password."},{status:400});
 const u=await env.DB.prepare("SELECT id,username,password_hash FROM users WHERE username=? OR email=?").bind(login.toLowerCase(),login.toLowerCase()).first();
 if(!u||u.password_hash!==await sha256(password)) return Response.json({error:"Invalid login details."},{status:401});
 const token=crypto.randomUUID()+crypto.randomUUID();
 await env.DB.prepare("INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,datetime('now','+7 days'))").bind(token,u.id).run();
 return new Response(JSON.stringify({ok:true,username:u.username}),{headers:{"content-type":"application/json","Set-Cookie":cookie("session",token,604800)}});
}

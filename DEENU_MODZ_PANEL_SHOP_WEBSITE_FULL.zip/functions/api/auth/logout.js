
export async function onRequestPost({env,request}) {
 const c=request.headers.get("Cookie")||"", m=c.match(/(?:^|;\s*)session=([^;]+)/);
 if(m) await env.DB.prepare("DELETE FROM sessions WHERE token=?").bind(m[1]).run();
 return new Response(JSON.stringify({ok:true}),{headers:{"content-type":"application/json","Set-Cookie":"session=; Max-Age=0; Path=/; HttpOnly; Secure; SameSite=Lax"}});
}


import { sha256 } from "../_crypto.js";
export async function onRequestPost({request,env}) {
 const {username,email,password}=await request.json();
 if(!username||!email||!password||password.length<6) return Response.json({error:"Enter username, email and a password of at least 6 characters."},{status:400});
 const exists=await env.DB.prepare("SELECT id FROM users WHERE username=? OR email=?").bind(username.toLowerCase(),email.toLowerCase()).first();
 if(exists) return Response.json({error:"Username or email already exists."},{status:409});
 const hash=await sha256(password);
 await env.DB.prepare("INSERT INTO users(username,email,password_hash,balance,created_at) VALUES(?,?,?,0,datetime('now'))").bind(username.toLowerCase(),email.toLowerCase(),hash).run();
 return Response.json({ok:true});
}

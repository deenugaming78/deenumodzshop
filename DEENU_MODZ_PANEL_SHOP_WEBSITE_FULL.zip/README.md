
# DEENU MODZ PANEL SHOP

Website structure based on the supplied screen recording:
- Create Account + Login
- Shop/dashboard layout
- Instant UPI Deposit page placeholder
- Transaction History
- My Orders
- My Reseller
- Profile and Logout
- Empty product areas (no products pre-added)
- Cloudflare Pages Functions + D1 database schema for real accounts

## Cloudflare setup
1. Create a D1 database named `deenu-modz-db`.
2. Put its database ID in `wrangler.toml`.
3. Run the migration against that D1 database:
   `wrangler d1 migrations apply deenu-modz-db --remote`
4. Deploy this project as a Cloudflare Pages project with Functions enabled.

## Important
Payment gateway/API secrets are intentionally NOT embedded in the frontend. Add them as server-side Cloudflare secrets/env vars and connect the exact provider API after its documentation is available.
